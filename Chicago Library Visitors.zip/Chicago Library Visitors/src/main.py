# Import utility libraries for handling csv files and file system.
import os
import pandas as pandas 

# Import data visualization libraries.
import folium as folium
from folium.plugins import TimestampedGeoJson
import geopandas as geopandas

# Load csv data containing Chicago library visitors by branch, by year (2011-2023). 
# Data source: https://catalog.data.gov/dataset/libraries-2023-visitors-by-location.
def ingest_data(): 
    data_folder='../data/'
    years=[]
    for file in os.listdir(data_folder):
        if file.endswith('.csv'):
            df = pandas.read_csv(os.path.join(data_folder, file), usecols=['BRANCH','YTD','LAT','LON']) 
            df['fill_color'] = '#2986CC'
            df['year'] = file[:4] + ''
            years.append(df)
    return years

def visualize_map(data):
    # format data for map
    geo_data = create_geojson(data)

    #load a map of Chicago and populate map with library visit data
    map = folium.Map(location = [41.85,-87.6],
                    tiles = "CartoDB Positron",
                    zoom_start = 11)

    #animate
    TimestampedGeoJson(geo_data,
                  period = 'P1Y',
                  duration = 'P1Y',
                  transition_time = 500,
                  auto_play = True).add_to(map)
    
    return map

def create_geojson(years_data):
    data={}
    features = []
    for year in years_data:
        for _, row in year.iterrows():
            feature = {
                'type': 'Feature',
                'geometry': {
                    'type':'Point', 
                    'coordinates':[row['LON'],row['LAT']]
                }
                ,'properties': {
                    'time': row['year'] + '-12-31',
                    'style': {'color' : ''},
                    'icon': 'circle',
                    'iconstyle':{
                        'fillColor': row['fill_color'],
                        'fillOpacity': 0.5,
                        'stroke': 'true',
                        'radius': row['YTD']*0.00002
                    }
                }
            }
            features.append(feature)
    data['type']='FeatureCollection'
    data['features']=features
    return data

def main():
    data = ingest_data()
    map = visualize_map(data)
    map.save('../html/chicago_library_visitors.html')

main()

# Potential future investigations...
# - what were the pandemic effects (2020-2022) by location?
# - does library visits correlate with economic development?
# - what are the effects of public transportation access on location visitors?